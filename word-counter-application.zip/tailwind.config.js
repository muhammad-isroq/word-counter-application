// tailwind.config.js
module.exports = {
  content: [
    './*.html', // Mengarahkan ke semua file HTML di folder yang sama
    './*.css',  // Mengarahkan ke semua file CSS di folder yang sama
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
